
export const Role = {
    SUPER_ADMIN: "SUPER_ADMIN",
    DEALER: "DEALER",
    OPERATOR: "OPERATOR",
    CLIENT: "CLIENT",
    ADMIN: "ADMIN",
    MANAGER: "MANAGER"
}
export class AboutDevice {}

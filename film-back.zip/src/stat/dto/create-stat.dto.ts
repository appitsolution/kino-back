export class CreateStatDto {}

export class CreateStatusDeviceDto {}

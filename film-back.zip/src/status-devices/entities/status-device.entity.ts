export class StatusDevice {}
